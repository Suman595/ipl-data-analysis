import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv("ipl_runs.csv")

# Group by Player and sum their total runs
top_batsmen = df.groupby("Player")["Runs"].sum().sort_values(ascending=False).head(10)

# Display top batsmen
print("🏏 Top 10 IPL Batsmen by Runs:\n")
print(top_batsmen)

# Plot the data
plt.figure(figsize=(10, 6))
top_batsmen.plot(kind="bar", color="orange")
plt.title("Top 10 IPL Batsmen by Total Runs")
plt.xlabel("Player")
plt.ylabel("Total Runs")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("ipl_chart.png")  # Saves the chart as a file
